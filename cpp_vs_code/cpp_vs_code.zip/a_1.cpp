#include <iostream>
using namespace std;
 
char maps[100 + 10][100 + 10];
int mm[4][2] = { {1, 0}, {0, 1}, {-1, 0}, {0, -1} };
 
int m, n;
 
bool dfs(int row, int col) {
    if (maps[row][col] == 'P')
        return true;
    maps[row][col] = '*';
    for (int i = 0; i < 4; i++) {
        int nextRow = row + mm[i][0];
        int nextCol = col + mm[i][1];
        if (nextRow >= 0 && nextRow < m && nextCol >= 0 && nextCol < n && maps[nextRow][nextCol] != '*')
            return dfs(nextRow, nextCol);
    }
    return false;
}
 
int main() {
    while (cin >> n >> m, n || m) {
        for (int i = 0; i < m; i++)
            cin >> maps[i];
 
        int startRow = -1, startCol;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (maps[i][j] == 'S') {
                    startRow = i;
                    startCol = j;
                }
            }
        }
 
        if (startRow == -1)
            cout << "NO" << endl;
        else
            cout << (dfs(startRow, startCol) ? "YES" : "NO") << endl;
    }
}